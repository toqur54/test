package toqur54.naver.com.launchapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ListViewActivity extends AppCompatActivity {
    Button close;
    ListView listView;
    TextView textview;

    final int RESULT_OK = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);
        close = findViewById(R.id.close);
        listView = findViewById(R.id.listview);
        textview = findViewById(R.id.textview);

        close.setOnClickListener(bClick);

        List<String> list = new ArrayList<String>(); //arrayList가 list안에 포함됨
        list.add("java");
        list.add("android");
        list.add("Spring");
        list.add("html");
        list.add("oracle");
        list.add("MySQL");
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,list);
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { //리스트뷰에 있는 하나의 값 클릭
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                final String selected = adapter.getItem(position); //position 위치의 배열값을 가져옴
                Toast.makeText(ListViewActivity.this,selected,Toast.LENGTH_SHORT).show();

                //Alert 메세지 띄우기
                AlertDialog.Builder builder = new AlertDialog.Builder(ListViewActivity.this);
                builder.setTitle("Dialog 확인").setMessage(selected).
                        setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent();
                                intent.putExtra("item",selected);
                                setResult(103,intent);
                                finish();
                            }
                        }).
                        setNegativeButton("취소", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }

    Button.OnClickListener bClick = new Button.OnClickListener(){

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.close:
                    finish();
                    break;
            }
        }
    };
}
