package toqur54.naver.com.launchapplication;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.concurrent.ExecutionException;

public class ProgressbarDateViewActivity extends AppCompatActivity {
    ProgressBar progressbar;
    LinearLayout layout;
    Intent intent;
    TextView count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progressbar_date_view);
        progressbar = findViewById(R.id.progressbar);
        layout = findViewById(R.id.layout);
        count = findViewById(R.id.count);
        intent = getIntent();
        progressbar.getIndeterminateDrawable().setColorFilter(Color.RED,
                PorterDuff.Mode.MULTIPLY);
        new Task().execute(intent.getStringExtra("item"));
//        String result="";
//        try {
//            result = new Task().execute(intent.getStringExtra("item")).get();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        } catch (ExecutionException e) {
//            e.printStackTrace();
//        }
//        Log.d("","------>>>>result : "+result);
    }

    class Task extends AsyncTask<String, Integer, String> {
        @Override
        protected void onPreExecute() {
            layout.setVisibility(View.VISIBLE);
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String str) {
            layout.setVisibility(View.INVISIBLE);
            super.onPostExecute(str);
            finish();
        }

        @Override
        protected String doInBackground(String... strings) {    //배열로 넘어옴
            progressbar.setScaleY(6f);
            String item = strings[0];
            Log.d("", "---- parms:" + item);
            for(int i=0; i<11; i++){
                try {
                    Thread.sleep(500);
                    progressbar.setProgress(i*10);
//                    count.setText(i+"");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return "returnValue";
        }
    }
}
