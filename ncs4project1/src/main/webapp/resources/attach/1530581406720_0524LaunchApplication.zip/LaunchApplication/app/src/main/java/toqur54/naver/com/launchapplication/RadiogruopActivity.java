package toqur54.naver.com.launchapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class RadiogruopActivity extends AppCompatActivity {
    Button chk;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radiogruop);
        chk = findViewById(R.id.chk);
        chk.setOnClickListener(bClick);
    }
    Button.OnClickListener bClick = new Button.OnClickListener(){

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.chk:
                    Toast.makeText(RadiogruopActivity.this,"확인",Toast.LENGTH_SHORT).show();
                    finish();
                    break;
            }
        }
    };
}
