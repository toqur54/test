package toqur54.naver.com.launchapplication;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import de.hdodenhof.circleimageview.CircleImageView;

public class CameraControlActivity extends AppCompatActivity {
    Button camera;
    Button close;
    CircleImageView noimage;
    private static final int REQUEST_IMAGE_CAPTURE = 672;
    private Uri photoUri;
    private String imageFilePath;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera_control);
        camera = findViewById(R.id.camera);
        close = findViewById(R.id.close);
        noimage = findViewById(R.id.noimage);
        camera.setOnClickListener(bClick);
        close.setOnClickListener(bClick);
    }
    Button.OnClickListener bClick = new Button.OnClickListener(){

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.camera:
                    Toast.makeText(CameraControlActivity.this,"camera...",Toast.LENGTH_SHORT).show();
                    sendTakePhotoIntent();
                    break;
                case R.id.close:
                    Toast.makeText(CameraControlActivity.this,"close..",Toast.LENGTH_SHORT).show();
                    finish();
                    break;
            }
        }
    };

    //성공
    //카메라를 띄우는 메소드
    private void sendTakePhotoIntent(){
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(intent.resolveActivity(getPackageManager()) !=null){
            startActivityForResult(intent,101);
        }
    }

    //이미지 파일 생성
    private File createImageFile() {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + ".jpg";
        File imageFile = null;
        File storageDir = new File(Environment.getExternalStorageDirectory() + "/Pictures", "files");

        if(!storageDir.exists()){
            storageDir.mkdirs();
        }
        imageFile = new File(storageDir, imageFileName);
        return imageFile;

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(requestCode == 101 && resultCode == RESULT_OK){
            //Bundle - 일종의 해쉬맵 구조(key,value), 번들에 사진 data를 담음
            Bundle extras = data.getExtras();
            //사진 data를 비트맵에 담음, Bitmap - 사진을 이용하기위한 클래스
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            //이미지 뷰에 setimageBitmap으로 사진을 넣음
            ((ImageView)findViewById(R.id.noimage)).setImageBitmap(imageBitmap);
            File savingfile = createImageFile();
            try {
                FileOutputStream fos = new FileOutputStream(savingfile);
                imageBitmap.compress(Bitmap.CompressFormat.JPEG,100,fos);
                fos.flush();
                fos.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
