package toqur54.naver.com.launchapplication;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class DatePickerActivity extends AppCompatActivity {
    EditText datepick;
    EditText dateresult;
    EditText date;
    Button search;
    Button close;
    private int get_yyyy;
    private int get_mm;
    private int get_dd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_picker);
        datepick = findViewById(R.id.datepick);
        dateresult = findViewById(R.id.dateresult);
        date = findViewById(R.id.date);
        search = findViewById(R.id.search);
        close = findViewById(R.id.close);

        datepick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("----->>", "click");
                showDatePickerDialog();
            }
        });
        //교수님방법
//        search.setOnClickListener(new Button.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String seleted = dateresult.getText().toString();
//                GregorianCalendar gc = new GregorianCalendar();
//                gc.set(get_yyyy,get_mm,get_dd);
//                gc.add(Calendar.DAY_OF_MONTH, Integer.parseInt(seleted));
//                date.setText(gc.get(Calendar.YEAR) + "년 " + (gc.get(Calendar.MONTH)+1) + "월 " + gc.get(Calendar.DAY_OF_MONTH) + "일");
//
//            }
//        });
    }

    private void showDatePickerDialog() {
        DialogFragment newFragment = new DatePickerFragmentCustom();
        newFragment.show(getFragmentManager(), "Time Picker");
    }

    @SuppressLint("ValidFragment")
    public class DatePickerFragmentCustom extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedlnstanceState) {
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            return new DatePickerDialog(getActivity(), this, year, month, day);
        }

        @Override
        public void onDateSet(DatePicker view, final int year, final int month, final int dayOfMonth) {
            Log.d("---->>", "ok..");
            datepick.setText(year + "년 " + (month + 1) + "월 " + dayOfMonth + "일");
            date.setText(year + "년 " + (month + 1) + "월 " + dayOfMonth + "일");
//            get_yyyy = year;
//            get_mm = month +1;
//            get_dd = dayOfMonth;

            search.setOnClickListener(new Button.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String seleted = dateresult.getText().toString();
                    GregorianCalendar gc = new GregorianCalendar();
                    gc.set(year, month, dayOfMonth);
                    gc.add(Calendar.DAY_OF_MONTH, Integer.parseInt(seleted));
                    date.setText(gc.get(Calendar.YEAR) + "년 " + (gc.get(Calendar.MONTH) + 1) + "월 " + gc.get(Calendar.DAY_OF_MONTH) + "일");

                }
            });
        }
    }

}
