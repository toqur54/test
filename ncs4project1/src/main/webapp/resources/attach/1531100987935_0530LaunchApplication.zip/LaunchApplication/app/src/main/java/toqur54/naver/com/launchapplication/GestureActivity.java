package toqur54.naver.com.launchapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class GestureActivity extends AppCompatActivity implements GestureDetector.OnGestureListener{
    LinearLayout baselayout;
    TextView gesturetxt;
    //좌표 값
    private static final int SWIPE_MIN_DISTANCE = 120;
    private static final int SWIPE_MAX_DISTANCE = 250;
    private static final int SWIPE_HRESHOLD = 200;
    GestureDetector gestureDetector;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gesture);
        baselayout = findViewById(R.id.baselayout);
        gesturetxt = findViewById(R.id.gesturetxt);
        gestureDetector = new GestureDetector(this);
    }
    @Override
    public boolean onTouchEvent(MotionEvent me){
        return gestureDetector.onTouchEvent(me);
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        int positionval = (int) (e1.getX() - e2.getX());
        if(e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > 200){    //200정도 이상 값이 나와야 인식 abs-절대값
            gesturetxt.setText("right to left");
            finish();
        }else if(e1.getX() - e2.getX() < SWIPE_MIN_DISTANCE && Math.abs(velocityX) > 200){
            gesturetxt.setText("left to right");
        }
        Toast.makeText(GestureActivity.this,"Fling..."+positionval,Toast.LENGTH_SHORT).show();
        return false;
    }
}
