package toqur54.naver.com.launchapplication;

import android.hardware.input.InputManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

public class KeyboardHideActivity extends AppCompatActivity {
    LinearLayout baselayout;
    EditText edit;
    InputMethodManager inputmanager; //키보드 제어 메소드
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keyboard_hide);

        inputmanager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        baselayout = findViewById(R.id.baselayout);
        edit = findViewById(R.id.edit);
        baselayout.setOnTouchListener(new MyTouchListener());
    }

    private class MyTouchListener implements View.OnTouchListener {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            Toast.makeText(KeyboardHideActivity.this,"hide...",Toast.LENGTH_SHORT).show();
            inputmanager.hideSoftInputFromWindow(edit.getWindowToken(),0); //EditText 클릭 후 키보드 숨김
            return false;
        }
    }
}
