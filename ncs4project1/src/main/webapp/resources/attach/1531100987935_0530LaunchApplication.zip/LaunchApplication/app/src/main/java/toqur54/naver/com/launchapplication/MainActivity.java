package toqur54.naver.com.launchapplication;

import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageButton cat1;
    ImageButton cat2;
    ImageButton img1;
    ImageButton img2;
    ImageButton icon;
    ImageButton firefox;
    ImageButton icon1;
    ImageButton icon2;
    ImageButton icon3;
    ImageButton icon4;
    ImageButton icon5;
    ImageButton icon6;
    ImageButton icon7;
    ImageButton icon8;
    ImageButton icon9;
    TextView textview;
    final int RESULT_OK = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        cat1 = findViewById(R.id.cat1);
        cat2 = findViewById(R.id.cat2);
        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
        icon = findViewById(R.id.icon);
        firefox = findViewById(R.id.firefox);
        icon1 = findViewById(R.id.icon1);
        icon2 = findViewById(R.id.icon2);
        icon3 = findViewById(R.id.icon3);
        icon4 = findViewById(R.id.icon4);
        icon5 = findViewById(R.id.icon5);
        icon6 = findViewById(R.id.icon6);
        icon7 = findViewById(R.id.icon7);
        icon8 = findViewById(R.id.icon8);
        icon9 = findViewById(R.id.icon9);
        textview = findViewById(R.id.textview);
        //클릭 이벤트
//        cat1.setOnClickListener(bClick);
//        cat2.setOnClickListener(bClick);
//        img1.setOnClickListener(bClick);
//        img2.setOnClickListener(bClick);

        //터치 이벤트
        cat1.setOnTouchListener(touch);
        cat2.setOnTouchListener(touch);
        img1.setOnTouchListener(touch);
        img2.setOnTouchListener(touch);
        icon.setOnTouchListener(touch);
        firefox.setOnTouchListener(touch);
        icon1.setOnTouchListener(touch);
        icon2.setOnTouchListener(touch);
        icon3.setOnTouchListener(touch);
        icon4.setOnTouchListener(touch);
        icon5.setOnTouchListener(touch);
        icon6.setOnTouchListener(touch);
        icon7.setOnTouchListener(touch);
        icon8.setOnTouchListener(touch);
        icon9.setOnTouchListener(touch);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    //버튼
    Button.OnClickListener bClick = new Button.OnClickListener(){

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.cat1:
                    Toast.makeText(MainActivity.this,"cat1..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.cat2:
                    Toast.makeText(MainActivity.this,"cat2..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.img1:
                    Toast.makeText(MainActivity.this,"img1..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.img2:
                    Toast.makeText(MainActivity.this,"img2..Click",Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };
    //터치
    View.OnTouchListener touch = new View.OnTouchListener(){

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (v.getId()){
                case R.id.cat1:
                    if(event.getAction() == MotionEvent.ACTION_DOWN){
                        cat1.setPadding(2,2,2,2);
                        cat1.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                    }else{
                        cat1.setPadding(0,0,0,0);
                        cat1.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                        Intent intent = new Intent(MainActivity.this, TargetActivity.class);//자기클래스,호출되는 클래스
                        intent.putExtra("id","kor");
                        intent.putExtra("name","korea");
//                        startActivity(intent);  //실행 그냥 실행할때
                        startActivityForResult(intent,RESULT_OK);   //결과값 가지고 실행할때
                    }
                    Toast.makeText(MainActivity.this,"cat1..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.cat2:
                    if(event.getAction() == MotionEvent.ACTION_DOWN){
                        cat2.setPadding(2,2,2,2);
                        cat2.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                    }else{
                        cat2.setPadding(0,0,0,0);
                        cat2.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                        Intent intent = new Intent(MainActivity.this, GirdLayoutActivity.class);
//                        startActivity(intent);
                        startActivityForResult(intent,RESULT_OK);
                    }
                    Toast.makeText(MainActivity.this,"cat2..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.img1:
                    if(event.getAction() == MotionEvent.ACTION_DOWN){
                        img1.setPadding(2,2,2,2);
                        img1.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                    }else{
                        img1.setPadding(0,0,0,0);
                        img1.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                        Intent intent = new Intent(MainActivity.this, ListViewActivity.class);
//                        startActivity(intent);
                        startActivityForResult(intent,RESULT_OK);
                    }
                    Toast.makeText(MainActivity.this,"img1..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.img2:
                    if(event.getAction() == MotionEvent.ACTION_DOWN){
                        img2.setPadding(2,2,2,2);
                        img2.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                    }else{
                        img2.setPadding(0,0,0,0);
                        img2.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                        Intent intent = new Intent(MainActivity.this, ProgressbarDateViewActivity.class);
                        intent.putExtra("item",textview.getText());
//                        startActivity(intent);
                        startActivityForResult(intent,RESULT_OK);
                    }
                    Toast.makeText(MainActivity.this,"img2..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.icon:
                    if(event.getAction() == MotionEvent.ACTION_DOWN){
                        icon.setPadding(2,2,2,2);
                        icon.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                    }else{
                        icon.setPadding(0,0,0,0);
                        icon.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                        Intent intent = new Intent(MainActivity.this, RadiogruopActivity.class);
                        startActivity(intent);
                    }
                    Toast.makeText(MainActivity.this,"icon..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.firefox:
                    if(event.getAction() == MotionEvent.ACTION_DOWN){
                        firefox.setPadding(2,2,2,2);
                        firefox.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                    }else{
                        firefox.setPadding(0,0,0,0);
                        firefox.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                        Intent intent = new Intent(MainActivity.this, YearListViewActivity.class);
                        startActivity(intent);
                    }
                    Toast.makeText(MainActivity.this,"firefox..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.icon1:
                    if(event.getAction() == MotionEvent.ACTION_DOWN){
                        icon1.setPadding(2,2,2,2);
                        icon1.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                    }else{
                        icon1.setPadding(0,0,0,0);
                        icon1.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                        Intent intent = new Intent(MainActivity.this, CameraControlActivity.class);
//                        startActivity(intent);
                        startActivityForResult(intent,RESULT_OK);
                    }
                    Toast.makeText(MainActivity.this,"icon1..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.icon2:
                    if(event.getAction() == MotionEvent.ACTION_DOWN){
                        icon2.setPadding(2,2,2,2);
                        icon2.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                    }else{
                        icon2.setPadding(0,0,0,0);
                        icon2.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                        Intent intent = new Intent(MainActivity.this, GestureActivity.class);
                        startActivity(intent);
                    }
                    Toast.makeText(MainActivity.this,"icon2..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.icon3:
                    if(event.getAction() == MotionEvent.ACTION_DOWN){
                        icon3.setPadding(2,2,2,2);
                        icon3.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                    }else{
                        icon3.setPadding(0,0,0,0);
                        icon3.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                        Intent intent = new Intent(MainActivity.this, TextZoomActivity.class);
                        startActivity(intent);

                    }
                    Toast.makeText(MainActivity.this,"icon3..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.icon4:
                    if(event.getAction() == MotionEvent.ACTION_DOWN){
                        icon4.setPadding(2,2,2,2);
                        icon4.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                    }else{
                        icon4.setPadding(0,0,0,0);
                        icon4.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                        Intent intent = new Intent(MainActivity.this, KeyboardHideActivity.class);
                        startActivity(intent);

                    }
                    Toast.makeText(MainActivity.this,"icon4..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.icon5:
                    if(event.getAction() == MotionEvent.ACTION_DOWN){
                        icon5.setPadding(2,2,2,2);
                        icon5.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                    }else{
                        icon5.setPadding(0,0,0,0);
                        icon5.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                        Intent intent = new Intent(MainActivity.this, DatePickerActivity.class);
                        startActivity(intent);
                    }
                    Toast.makeText(MainActivity.this,"icon5..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.icon6:
                    if(event.getAction() == MotionEvent.ACTION_DOWN){
                        icon6.setPadding(2,2,2,2);
                        icon6.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                    }else{
                        icon6.setPadding(0,0,0,0);
                        icon6.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);

                    }
                    Toast.makeText(MainActivity.this,"icon6..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.icon7:
                    if(event.getAction() == MotionEvent.ACTION_DOWN){
                        icon7.setPadding(2,2,2,2);
                        icon7.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                    }else{
                        icon7.setPadding(0,0,0,0);
                        icon7.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);

                    }
                    Toast.makeText(MainActivity.this,"icon7..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.icon8:
                    if(event.getAction() == MotionEvent.ACTION_DOWN){
                        icon8.setPadding(2,2,2,2);
                        icon8.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                    }else{
                        icon8.setPadding(0,0,0,0);
                        icon8.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);

                    }
                    Toast.makeText(MainActivity.this,"icon8..Click",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.icon9:
                    if(event.getAction() == MotionEvent.ACTION_DOWN){
                        icon9.setPadding(2,2,2,2);
                        icon9.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);
                    }else{
                        icon9.setPadding(0,0,0,0);
                        icon9.setColorFilter(1111, PorterDuff.Mode.SRC_OVER);

                    }
                    Toast.makeText(MainActivity.this,"icon9..Click",Toast.LENGTH_SHORT).show();
                    break;
            }
            return false;
        }
    };

    //데이터 값 받아오기
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == 101){
            Toast.makeText(MainActivity.this,data.getStringExtra("id"),Toast.LENGTH_SHORT).show();
        }if(resultCode == 102){
            Toast.makeText(MainActivity.this,data.getStringExtra("name"),Toast.LENGTH_SHORT).show();
        }if(resultCode == 103){
//            String item = data.getStringExtra("item");
            Log.d("",""+data.getStringExtra("item"));
            textview.setText(data.getStringExtra("item"));
        }
//        if(requestCode == RESULT_OK){
//            Toast.makeText(MainActivity.this,data.getStringExtra("id"),Toast.LENGTH_SHORT).show();
//        }
    }

}
