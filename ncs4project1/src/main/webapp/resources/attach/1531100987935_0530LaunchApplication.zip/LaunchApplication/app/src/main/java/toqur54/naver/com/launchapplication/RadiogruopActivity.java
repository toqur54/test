package toqur54.naver.com.launchapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class RadiogruopActivity extends AppCompatActivity {
    Button chk;
    RadioGroup gender;
    Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radiogruop);
        chk = findViewById(R.id.chk);
        gender = findViewById(R.id.gender);
        spinner = findViewById(R.id.spinner);
        chk.setOnClickListener(bClick);
    }
    Button.OnClickListener bClick = new Button.OnClickListener(){

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.chk:
                    //라디오그룹
                    int seleted = gender.getCheckedRadioButtonId();
                    RadioButton seletedbtn = findViewById(seleted);
                    String what = seletedbtn.getText().toString();
                    Toast.makeText(RadiogruopActivity.this,what,Toast.LENGTH_SHORT).show();
                    //스피너
                    String subject = spinner.getSelectedItem().toString();
                    Toast.makeText(RadiogruopActivity.this,subject,Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };
}
