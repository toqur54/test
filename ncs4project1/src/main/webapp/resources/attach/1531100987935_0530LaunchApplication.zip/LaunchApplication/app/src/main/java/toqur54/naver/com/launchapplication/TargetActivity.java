package toqur54.naver.com.launchapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class TargetActivity extends AppCompatActivity {
    TextView text;
    Button close;
    final int RESULT_OK = 1;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_target);
        text = findViewById(R.id.text);
        close = findViewById(R.id.close);
        close.setOnClickListener(bClick);
        intent = getIntent();
        String id = intent.getExtras().getString("id");
        String name = intent.getStringExtra("name");
        text.setText(id+"  "+name);

    }
    Button.OnClickListener bClick = new Button.OnClickListener(){

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.close:
                    intent.putExtra("id","usa");
                    intent.putExtra("name","america");
//                    setResult(RESULT_OK, intent);
                    setResult(101,intent);
                    finish();

            }
        }
    };
}
