package toqur54.naver.com.launchapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class TextZoomActivity extends AppCompatActivity {
    TextView mytv;
    final static float STEP = 200;
    float mRatio = 1.0f; //폰트 크기
    int mBaseDist;
    float mBaseRatio;
    float fontsize = 13;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_zoom);
        mytv = findViewById(R.id.mytv);
        mytv.setTextSize(mRatio + 13);
        mytv.setOnTouchListener(new MyTouchlistener());

    }

    private class MyTouchlistener implements View.OnTouchListener {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if(event.getPointerCount() == 2){//폰 화면에 손가락 2개가 터치시 작동
                int action = event.getAction();
                int pureaction = action & MotionEvent.ACTION_MASK;
                if(pureaction == MotionEvent.ACTION_POINTER_DOWN){
                    mBaseDist = getDistance(event);
                    mBaseRatio = mRatio;
                }else{
                    float delta = (getDistance(event) - mBaseDist) / STEP;
                    float multi = (float) Math.pow(2, delta);
                    mRatio = Math.min(1024.0f,Math.max(0.1f,mBaseRatio * multi));
                    mytv.setTextSize(mRatio + 13);
                }
                Toast.makeText(TextZoomActivity.this,"MyTouchlistener...",Toast.LENGTH_SHORT).show();
            }
            return false;
        }
    }
    int getDistance(MotionEvent event){//x좌표 y좌표 선택해서 줌인아웃 확인
        int dx = (int) (event.getX(0) - event.getX(1));
        int dy = (int) (event.getY(0) - event.getY(1));
        return (int) Math.sqrt(dx * dx + dy * dy);
    }
}
