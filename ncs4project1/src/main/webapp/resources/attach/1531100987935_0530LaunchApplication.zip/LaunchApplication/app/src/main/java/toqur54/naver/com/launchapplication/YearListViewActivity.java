package toqur54.naver.com.launchapplication;

import android.app.Dialog;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.BatchUpdateException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

public class YearListViewActivity extends AppCompatActivity {
    Button close;
    ListView yearlist;
    TextView yeartxt;
    Dialog yyyyDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_year_list_view);
        showYearDialog();
    }

    //날짜 배열(현재 년도 기준)
    void showYearDialog(){
        GregorianCalendar today = new GregorianCalendar();
        int currently = today.get(Calendar.YEAR);
        String[] yyyy = new String[currently - 1900 +1];    //2018-1900+1 = 119개 공간생성
        int maxyy = currently - 1900;
        for(int i=1; i<=maxyy; i++){
            yyyy[i] = (1900 + i)+"";
        }

        //다이얼로그 adapter 처럼 쓰임
        final LayoutInflater yyyyli = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View yyyyv = yyyyli.inflate(R.layout.activity_year_list_view,null,false);
        //사용자생성 다이얼로그
        yyyyDialog = new Dialog(YearListViewActivity.this);
        yyyyDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);//타이틀 x
        yyyyDialog.setContentView(yyyyv);
        yyyyDialog.setCancelable(true);

        yearlist = yyyyDialog.findViewById(R.id.yearlist);
        yearlist.setAdapter(new ArrayAdapter<String>(this,R.layout.activity_year_list_view,yyyy){
            @Override
            public View getView( int position, View convertView, ViewGroup parent ) {
                TextView txt = new TextView(this.getContext());
                txt.setTextSize(30);
                txt.setText(this.getItem(position));
                return txt;
            }
        });
        yearlist.setSelectionFromTop(90,1); //처음 실행하면 뜨는 위치
        //클릭시 텍스트 뷰에 값 넣기
        yearlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selected = yearlist.getItemAtPosition(position).toString();
                yeartxt = yyyyDialog.findViewById(R.id.yeartxt);
                yeartxt.setText(selected);
                Toast.makeText(YearListViewActivity.this,selected+"년",Toast.LENGTH_SHORT).show();
            }
        });
        yyyyDialog.show();
        //생성 다이얼로그에서 가져와야 오류안뜸
        close = yyyyDialog.findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
